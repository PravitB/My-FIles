# Inventory Sort

A quality of life datapack that will sort your inventory (excluding hotbar) into a defined group ordering.

## Installation

1. Visit the [Releases](https://github.com/dthigpen/dtcraft-datapacks/releases) page and download the desired datapack zip file.
2. Copy the downloaded zip file into your world's datapacks folder at `%APPDATA%\.minecraft\saves\<world>\datapacks`
3. Launch the world and type `/reload`
4. Check that the datapack is installed under the "Installed Datapacks" Advancement tab with `Ctrl + L`

## Usage
Sort your inventory with the command `/trigger dt.sort`